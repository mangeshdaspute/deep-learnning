[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/BAyVj2mn)
# homework3_2023

- Write your own `model.py` and train it using the training loop in `homework3.ipynb`
- Once your training reaches >80% accuracy on the validation dataset, please add and commit your `model.py` and `trained_model.pt`
- Hint: try looking at the model in [Tutorial 8](https://github.com/WeizmannMLcourse/MLCourse_2023/tree/main/Tutorial8%20-%20graphs%20with%20DGL)
